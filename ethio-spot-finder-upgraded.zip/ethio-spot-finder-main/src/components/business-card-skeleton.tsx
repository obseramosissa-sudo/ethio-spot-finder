export function BusinessCardSkeleton() {
  return (
    <div className="flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
      <div className="aspect-[4/3] animate-pulse bg-muted" />
      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="h-3 w-16 animate-pulse rounded-full bg-muted" />
        <div className="h-5 w-3/4 animate-pulse rounded-full bg-muted" />
        <div className="h-3 w-full animate-pulse rounded-full bg-muted" />
        <div className="h-3 w-2/3 animate-pulse rounded-full bg-muted" />
        <div className="mt-auto flex items-center justify-between pt-2">
          <div className="h-3 w-24 animate-pulse rounded-full bg-muted" />
          <div className="h-3 w-8 animate-pulse rounded-full bg-muted" />
        </div>
      </div>
    </div>
  );
}
