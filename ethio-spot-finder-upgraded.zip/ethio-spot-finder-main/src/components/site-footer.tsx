import { Link } from "@tanstack/react-router";
import { Instagram, Facebook, Twitter, ArrowRight } from "lucide-react";
import { useState } from "react";
import logoAsset from "@/assets/ethio-spot-logo.png.asset.json";

const social = [
  { icon: Instagram, label: "Instagram", href: "https://instagram.com" },
  { icon: Facebook, label: "Facebook", href: "https://facebook.com" },
  { icon: Twitter, label: "Twitter / X", href: "https://twitter.com" },
];

export function SiteFooter() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  return (
    <footer className="mt-24 border-t border-border bg-secondary/40">
      {/* Newsletter capture */}
      <div className="border-b border-border">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <div className="flex flex-col items-start justify-between gap-5 rounded-2xl bg-brand-gradient p-6 text-brand-foreground shadow-brand sm:flex-row sm:items-center sm:p-8">
            <div>
              <div className="font-display text-lg font-bold sm:text-xl">Get new spots in your inbox</div>
              <p className="mt-1 text-sm text-white/85">
                One email a month — new openings, collections, and local favorites.
              </p>
            </div>
            {sent ? (
              <div className="rounded-full bg-white/15 px-5 py-3 text-sm font-semibold">
                Thanks — you're on the list! 🎉
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (email) setSent(true);
                }}
                className="flex w-full max-w-sm gap-2 sm:w-auto"
              >
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@email.com"
                  className="w-full min-w-0 rounded-full bg-white/95 px-4 py-3 text-sm text-foreground outline-none placeholder:text-muted-foreground"
                />
                <button
                  type="submit"
                  className="group inline-flex shrink-0 items-center gap-1.5 rounded-full bg-gold-gradient px-4 py-3 text-sm font-semibold text-gold-foreground transition duration-300 hover:scale-105 active:scale-95"
                >
                  Join
                  <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4 lg:px-8">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            <img src={logoAsset.url} alt="Ethio Spot logo" className="h-9 w-auto" />
            <span className="font-display text-lg font-bold">
              Ethio <span className="text-brand">Spot</span>
            </span>
          </div>

          <p className="mt-3 max-w-sm text-sm text-muted-foreground">
            Discover Ethiopian businesses on the map — restaurants, cafés, shops, spas and more.
            Locate what you love in seconds.
          </p>

          <div className="mt-5 flex items-center gap-2">
            {social.map((s) => (
              <a
                key={s.label}
                href={s.href}
                target="_blank"
                rel="noreferrer"
                aria-label={s.label}
                className="grid h-9 w-9 place-items-center rounded-full border border-border text-muted-foreground transition duration-300 hover:-translate-y-0.5 hover:border-brand hover:text-brand hover:shadow-soft"
              >
                <s.icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
        <div>
          <div className="text-sm font-semibold">Explore</div>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/directory" className="story-link hover:text-foreground">Directory</Link></li>
            <li><Link to="/categories" className="story-link hover:text-foreground">Categories</Link></li>
            <li><Link to="/collections" className="story-link hover:text-foreground">Collections</Link></li>
            <li><Link to="/map" className="story-link hover:text-foreground">Map</Link></li>
            <li><Link to="/search" className="story-link hover:text-foreground">Search</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-sm font-semibold">For Owners</div>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/register" className="story-link hover:text-foreground">List your business</Link></li>
            <li><Link to="/login" className="story-link hover:text-foreground">Owner login</Link></li>
            <li><Link to="/dashboard" className="story-link hover:text-foreground">Dashboard</Link></li>
            <li><Link to="/admin" className="story-link hover:text-foreground">Admin</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-muted-foreground sm:flex-row sm:px-6 lg:px-8">
          <span>© {new Date().getFullYear()} Ethio Spot. All rights reserved.</span>
          <span>Made with <span className="text-brand">green</span> & <span className="text-gold">gold</span> in Addis Ababa.</span>
        </div>
      </div>
    </footer>
  );
}
